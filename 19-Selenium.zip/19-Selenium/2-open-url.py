from selenium import webdriver

driver = webdriver.Edge()

driver.get("https://zen-browser.app/")