# Selenium is for automation.
# It is used for testing purposes.
# pip install selenium and web driver was installed.