# Buffer says, data is divided into chunks.
# If I do s.recv(10) I won't recieve complete data.